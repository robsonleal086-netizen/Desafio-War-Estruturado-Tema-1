#include <stdio.h>
#include <string.h>

#define MAX_TERRITORIOS 5
#define TAM_NOME 30
#define TAM_COR  15

typedef struct {
    char nome[TAM_NOME];
    char cor[TAM_COR];
    int tropas;
} Territorio;

void inicializarTerritorios(Territorio territorios[], int tamanho);
void cadastrarTerritorios(Territorio territorios[], int tamanho);
void exibirTerritorio(const Territorio *t);
void exibirTodosTerritorios(const Territorio territorios[], int tamanho);
void atualizarTropas(Territorio territorios[], int tamanho);
int  buscarTerritorioPorNome(const Territorio territorios[], int tamanho, const char *nome);
void limparEntrada();

int main(void) {
    Territorio territorios[MAX_TERRITORIOS];
    int opcao;

    inicializarTerritorios(territorios, MAX_TERRITORIOS);

    do {
        printf("\n=== DESAFIO WAR ESTRUTURADO - TEMA 1 ===\n");
        printf("1 - Cadastrar territorios\n");
        printf("2 - Listar territorios\n");
        printf("3 - Atualizar numero de tropas de um territorio\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        if (scanf("%d", &opcao) != 1) {
            printf("Entrada invalida. Tente novamente.\n");
            limparEntrada();
            continue;
        }

        limparEntrada();

        switch (opcao) {
            case 1:
                cadastrarTerritorios(territorios, MAX_TERRITORIOS);
                break;
            case 2:
                exibirTodosTerritorios(territorios, MAX_TERRITORIOS);
                break;
            case 3:
                atualizarTropas(territorios, MAX_TERRITORIOS);
                break;
            case 0:
                printf("Encerrando o programa...\n");
                break;
            default:
                printf("Opcao invalida. Tente novamente.\n");
        }

    } while (opcao != 0);

    return 0;
}

void inicializarTerritorios(Territorio territorios[], int tamanho) {
    int i;
    for (i = 0; i < tamanho; i++) {
        strcpy(territorios[i].nome, "N/A");
        strcpy(territorios[i].cor, "N/A");
        territorios[i].tropas = 0;
    }
}

void cadastrarTerritorios(Territorio territorios[], int tamanho) {
    int i;

    printf("\n--- Cadastro de Territorios ---\n");

    for (i = 0; i < tamanho; i++) {
        printf("\nTerritorio %d de %d\n", i + 1, tamanho);

        printf("Nome do territorio: ");
        fgets(territorios[i].nome, TAM_NOME, stdin);
        territorios[i].nome[strcspn(territorios[i].nome, "\n")] = '\\0';

        printf("Cor (ex: Vermelho, Azul, Verde): ");
        fgets(territorios[i].cor, TAM_COR, stdin);
        territorios[i].cor[strcspn(territorios[i].cor, "\n")] = '\\0';

        printf("Quantidade de tropas: ");
        if (scanf("%d", &territorios[i].tropas) != 1) {
            printf("Valor invalido. Definindo tropas = 0.\n");
            territorios[i].tropas = 0;
        }

        limparEntrada();
    }

    printf("\nCadastro concluido!\n");
}

void exibirTerritorio(const Territorio *t) {
    printf("Nome : %s\n", t->nome);
    printf("Cor  : %s\n", t->cor);
    printf("Tropas: %d\n", t->tropas);
}

void exibirTodosTerritorios(const Territorio territorios[], int tamanho) {
    int i;

    printf("\n--- Lista de Territorios ---\n");

    for (i = 0; i < tamanho; i++) {
        printf("\nTerritorio %d:\n", i + 1);
        exibirTerritorio(&territorios[i]);
    }
}

int buscarTerritorioPorNome(const Territorio territorios[], int tamanho, const char *nome) {
    int i;
    for (i = 0; i < tamanho; i++) {
        if (strcmp(territorios[i].nome, nome) == 0) {
            return i;
        }
    }
    return -1;
}

void atualizarTropas(Territorio territorios[], int tamanho) {
    char nomeBusca[TAM_NOME];
    int novoValor;
    int indice;

    printf("\n--- Atualizar Tropas ---\n");
    printf("Digite o nome exato do territorio: ");
    fgets(nomeBusca, TAM_NOME, stdin);
    nomeBusca[strcspn(nomeBusca, "\n")] = '\\0';

    indice = buscarTerritorioPorNome(territorios, tamanho, nomeBusca);

    if (indice == -1) {
        printf("Territorio '%s' nao encontrado.\n", nomeBusca);
        return;
    }

    printf("Territorio encontrado:\n");
    exibirTerritorio(&territorios[indice]);

    printf("\nDigite o novo numero de tropas: ");
    if (scanf("%d", &novoValor) != 1) {
        printf("Valor invalido. Operacao cancelada.\n");
        limparEntrada();
        return;
    }

    limparEntrada();
    territorios[indice].tropas = novoValor;

    printf("Tropas atualizadas com sucesso!\n");
}

void limparEntrada() {
    int c;
    while ((c = getchar()) != '\\n' && c != EOF) {}
}
